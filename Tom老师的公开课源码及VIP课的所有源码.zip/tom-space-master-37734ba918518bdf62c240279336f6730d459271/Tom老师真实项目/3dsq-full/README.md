# 这是Tom老师曾经的一个创业项目，做一个类似于58到家、京东到家的社区APP后台，无UI界面代码
## 由于资金链断裂，最终导致项目无法上线，当然项目功能有些还会没有完善。
## 此项目源码不存在版权问题，在这里贡献给大家参考
## 如果有机会接到外包项目，也可以以此为基础进行升级改造

# admin	  admin.3dsq.me  提供给后台系统调用的
# center	  i.3dsq.me      用户中心
# core      公共服务
# explorer  resouce.3dsq.me    资源管理服务
# express   ex.3dsq.me         快递服务
# model     实体类公共的
# ocr       图像识别(识别身份证)
# passport  用户登录和注册
# pay       支付，支持微信和支付宝
# portal    SaaS门户  xxx.3dsq.me
# property  property.3dsq.me   物业服务
# search    s.3dsq.me       搜索服务
# shopping  mall.3dsq.me    购物
# sns       bbs.3dsq.me     社区
