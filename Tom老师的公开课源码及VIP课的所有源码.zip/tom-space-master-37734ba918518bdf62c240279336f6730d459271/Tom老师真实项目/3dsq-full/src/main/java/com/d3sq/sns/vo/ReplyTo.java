package com.d3sq.sns.vo;

public class ReplyTo {
	
	private Long replyToUid;
	private String replyToName;

	public Long getReplyToUid() {
		return replyToUid;
	}

	public void setReplyToUid(Long replyToUid) {
		this.replyToUid = replyToUid;
	}

	public String getReplyToName() {
		return replyToName;
	}

	public void setReplyToName(String replyToName) {
		this.replyToName = replyToName;
	}

}
