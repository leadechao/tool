package com.d3sq.model.helper;

/**
 * 条款列表json格式定义
 *
 */
public class ListItem {
	private String icon;	//图标
	private String name;	//名称
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
