package com.d3sq.explorer.service.impl;

import org.springframework.stereotype.Service;

import com.d3sq.explorer.service.IResourceService;

/**
 * 资源管理
 */
@Service
public class ResourceServiceImpl implements IResourceService {
	
	
	
}
