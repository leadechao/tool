package com.d3sq.test.ocr;

//import java.io.File;

//import net.sourceforge.tess4j.ITesseract;
//import net.sourceforge.tess4j.Tesseract;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@ContextConfiguration(locations = {"classpath*:application-context.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class OCRTest {

	@Test
	@Ignore
	public void test(){
		
//		ITesseract instance = new Tesseract();
//		instance.setLanguage("eng");
////	    System.out.println("doOCR on a PNG image");  
//        File imageFile = new File("/Users/tom/Desktop/第二代身份证(电子版).jpg");  
////        String expResult = "The (quick) [brown] {fox} jumps!\nOver the $43,456.78 <lazy> #90 dog";  
//        String result;
//		try {
//			result = instance.doOCR(imageFile);
//			System.out.println(result);  
//		} catch (Exception e) {
//			e.printStackTrace();
//		}  
		
		
	}
	
}
