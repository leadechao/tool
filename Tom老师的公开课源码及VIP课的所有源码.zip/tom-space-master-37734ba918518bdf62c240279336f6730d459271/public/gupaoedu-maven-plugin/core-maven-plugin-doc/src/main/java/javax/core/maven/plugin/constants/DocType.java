package javax.core.maven.plugin.constants;

public enum DocType {
	HTML,
	WORD
}
