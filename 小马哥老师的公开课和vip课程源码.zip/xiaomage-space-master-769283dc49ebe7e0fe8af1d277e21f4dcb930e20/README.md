# 小马哥的空间



## 我是谁?

这是一个很好的问题！

小马哥，十余年Java EE 从业经验，架构师、微服务布道师。目前主要
负责一线互联网公司微服务技术实施、架构衍进、基础设施构建等。重点关注云计算、微服务以及软件架构等领域。通过SUN Java（SCJP、SCWCD、SCBCD）以及Oracle OCA 等的认证。



## 课程体系

### [VIP 课](http://git.gupaoedu.com/vip/xiaomage-space/tree/master/VIP%E8%AF%BE)

### [公开课](http://git.gupaoedu.com/vip/xiaomage-space/tree/master/%E5%85%AC%E5%BC%80%E8%AF%BE)



## 联系方式

### QQ : 1191971402

### 微信：需要吗？



