package com.gupao.service;

import com.gupao.domain.User;

/**
 * 用户服务
 *
 * @author 小马哥 QQ 1191971402
 * @copyright 咕泡学院出品
 * @since 2018/1/28
 */
public interface UserService {

    boolean addUser(User user);

}
