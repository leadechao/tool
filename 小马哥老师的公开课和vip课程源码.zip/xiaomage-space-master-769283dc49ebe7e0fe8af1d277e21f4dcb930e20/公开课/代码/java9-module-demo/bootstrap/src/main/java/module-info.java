/**
 * 引导模块
 *
 * @author 小马哥 QQ 1191971402
 * @copyright 咕泡学院出品
 * @since 2018/1/28
 */
module bootstrap {

    requires user.service;
}