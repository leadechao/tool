package com.gupao.studysourcecode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudySourceCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudySourceCodeApplication.class, args);
	}
}
