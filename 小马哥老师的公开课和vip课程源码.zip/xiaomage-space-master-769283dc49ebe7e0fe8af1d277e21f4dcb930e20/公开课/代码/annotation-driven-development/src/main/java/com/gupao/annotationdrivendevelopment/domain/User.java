package com.gupao.annotationdrivendevelopment.domain;

/**
 * 用户
 * 广告资源位...
 *
 * @author mercyblitz
 * @date 2017-10-09
 **/
public class User {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
