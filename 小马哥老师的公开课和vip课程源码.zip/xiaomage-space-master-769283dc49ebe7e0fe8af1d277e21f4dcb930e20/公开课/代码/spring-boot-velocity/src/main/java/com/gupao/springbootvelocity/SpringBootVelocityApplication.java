package com.gupao.springbootvelocity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootVelocityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootVelocityApplication.class, args);
	}
}
