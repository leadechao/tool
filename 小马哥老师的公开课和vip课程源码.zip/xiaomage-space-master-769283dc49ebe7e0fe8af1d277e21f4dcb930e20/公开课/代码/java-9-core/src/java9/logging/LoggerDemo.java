package java9.logging;

/**
 * TODO:小马哥，写点注释吧！
 *
 * @author mercyblitz
 * @email mercyblitz@gmail.com
 * @date 2017-10-20
 **/
public class LoggerDemo {
    public static void main(String[] args) {



    }
}
