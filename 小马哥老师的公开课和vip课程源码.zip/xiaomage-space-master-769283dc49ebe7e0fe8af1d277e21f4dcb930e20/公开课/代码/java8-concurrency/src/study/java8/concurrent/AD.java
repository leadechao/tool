package study.java8.concurrent;

/**
 * TODO:小马哥，写点注释吧！
 * 广告资源位...
 *
 * @author mercyblitz
 * @date 2017-09-24
 **/
public class AD {
}
