package com.gupao.springxmlextension;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringXmlExtensionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringXmlExtensionApplication.class, args);
	}
}
